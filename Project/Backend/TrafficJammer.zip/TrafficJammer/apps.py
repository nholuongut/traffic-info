from django.apps import AppConfig


class TrafficjammerConfig(AppConfig):
    name = 'TrafficJammer'
