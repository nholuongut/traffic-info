from django.http import HttpResponse
from django.shortcuts import render
import json
import math
from datetime import datetime,timezone,timedelta
from django.views.decorators.csrf import csrf_exempt

from TrafficJammer.models import Street, \
    Section, \
    Transit, \
    Accident, \
    SectionSerializer, \
    StreetSerializer, \
    StreetInputSerializer, \
    AccidentSerializer

# Create your views here.

@csrf_exempt
def info_street(request):
    if request.method=="GET":
        return HttpResponse(json.dumps(SectionSerializer(Section.objects.all(),many=True).data))

@csrf_exempt
def street(request):
    try:
        if request.method=="POST":
            print("ola")
            #Todo serializable is_valid
            #Todo check all parameters check if we need to send before-hand
            #todo check if there isnt any overlap
            #Todo when creating a section need to verify the connections
            '''
            Creating a new street
            '''
            data=json.loads(request.body)
            name=data.get("street")
            begin_coord_x,begin_coord_y=(data.get("beggining")[0],data.get("beggining")[1])
            ending_coord_x,ending_coord_y=(data.get("ending")[0],data.get("ending")[1])
            length=math.hypot(begin_coord_x-ending_coord_x,begin_coord_y-ending_coord_y)

            street_obj=Street(name=name,
                          begin_coord_x=begin_coord_x,
                          begin_coord_y=begin_coord_y,
                          ending_coord_x=ending_coord_x,
                          ending_coord_y=ending_coord_y,
                          length=length)
            street_obj.save()

            '''
            Turning the street into different sections
            Each section is aprox 500m of a street, if the street is made of sections that aren't divisible by 500
            the last section will be the rest 1200=500+500+200
            '''
            number_of_divisions=(length/(500))
            print(number_of_divisions)

            for i in range(math.ceil(number_of_divisions)):

                begin_x=i*((ending_coord_x-begin_coord_x)/number_of_divisions)
                begin_y=i*((ending_coord_y-begin_coord_y)/number_of_divisions)
                f=i
                end_coord_x=((f+1)*((ending_coord_x-begin_coord_x)/number_of_divisions))
                end_coord_y=((f+1)*((ending_coord_y-begin_coord_y)/number_of_divisions))

                if end_coord_x>ending_coord_x:
                    end_coord_x=ending_coord_x
                    print("changing")
                if end_coord_y>ending_coord_y:
                    end_coord_y=ending_coord_y
                    print("changing")
                create_section(street_obj,begin_x,begin_y,end_coord_x,end_coord_y,True)
                create_section(street_obj,begin_x,begin_y,end_coord_x,end_coord_y,False)

            return HttpResponse(json.dumps(StreetInputSerializer(street_obj).data))
    except:
        #TODO make this according to standards
        return HttpResponse("ERROR")

@csrf_exempt
def car_to_street(request):
    try:
        if request.method=="PUT":
            section=Section.objects.get(id=json.loads(request.body).get('id'))
            section.number_cars += 1
            section.save()
            add_to_transit(section)
            return HttpResponse(json.dumps(SectionSerializer(section).data))
        elif request.method=="DELETE":
            section = Section.objects.get(id=json.loads(request.body).get('id'))
            section.number_cars -= 1
            section.save()
            return HttpResponse(json.dumps(SectionSerializer(section).data))
    except Exception as e:
        return HttpResponse("ERROR")

@csrf_exempt
def add_to_accident(request):
    if request.method=="POST":
        data=json.loads(request.body)
        section=Section.objects.get(id=data.get("id"))
        accident= Accident(section=section,coord_x=data.get("x_coord"),coord_y=data.get("y_coord"),date=datetime.now(timezone.utc))
        accident.save()
        return HttpResponse(json.dumps(AccidentSerializer(accident).data))
    return

def add_to_transit(section,transit=200):
    time_of_transit = datetime.now(timezone.utc)
    last_time_of_transit = sorted(Transit.objects.filter(section=section),key=lambda transit:transit.date,reverse=True)
    if section.number_cars>transit:
        if last_time_of_transit[0].date+timedelta(minutes=30)<time_of_transit:
            transit = Transit(date=time_of_transit,section=section)
            transit.save()

def create_section(street,coord_x,coord_y,end_x,end_y,direction):
    section = Section(street=street,
                      beggining_coords_x=coord_x,
                      beggining_coords_y=coord_y,
                      ending_coords_x=end_x,
                      ending_coords_y=end_y,
                      actual_direction=direction)
    section.save()